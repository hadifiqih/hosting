<?php

namespace Intervention\Image\Exception;

class NotReadableException extends ImageException
{
    # nothing to override
}
